# WASL Chat — Flutter MVP starter

This is a starter source project for the first version of the WASL chat app.

## Important status
- This package contains source code and setup instructions.
- It is **not** a compiled APK and is **not** connected to a live backend yet.
- The current app uses demo users/messages so you can test the UI.
- Real authentication, cross-device messaging, audio upload, server-enforced country filtering, moderation tooling, and account deletion require Firebase configuration and backend rules before public release.

## Product decisions
- Free at launch: no ads, no subscriptions, no paid filters.
- Country is detected from device location at onboarding; no manual country switch in the user-facing flow.
- The app stores a country code in the profile, not raw GPS coordinates.
- The app shows a demo chat list and a demo conversation until Firebase is connected.
- Text and audio messages must be protected by server-side access rules in production.

## Requirements
- Flutter stable SDK
- Android Studio / Android SDK
- A Firebase project for live features
- Android phone or emulator for testing

## Run the prototype
1. Install Flutter and Android Studio.
2. In this folder, run:
   ```bash
   flutter create .
   flutter pub get
   flutter run
   ```
3. If Flutter reports an Android package or Gradle setup issue, open the folder in Android Studio and let it sync.

## Enable live Firebase services (next implementation step)
1. Create a Firebase project.
2. Register an Android app with package name `com.example.waslchat`.
3. Add `google-services.json` under `android/app/`.
4. Configure FlutterFire with `flutterfire configure`.
5. Replace the demo repository with Firebase Authentication, Firestore, and private Cloud Storage implementations.
6. Add Firestore and Storage security rules that enforce:
   - users can only read profiles from their assigned country,
   - only conversation participants can read/write messages,
   - only participants can access audio files,
   - blocked users cannot initiate or continue messages,
   - country code cannot be changed by client-side updates.
7. Add moderation and deletion workflows before any public release.

## Suggested free-first architecture
- Flutter: Android client
- Firebase Authentication: accounts
- Cloud Firestore: profiles and messages
- Cloud Storage: voice clips
- Cloud Functions or a trusted server: country assignment, abuse controls, deletion and moderation workflows

Firebase free quotas are limited and can change; monitor usage and set budget alerts. A public chat service is not guaranteed to remain free at scale.

## Privacy and safety checklist before release
- Publish a privacy policy and terms of service.
- Add in-app report and block controls.
- Provide a moderation/admin process and response policy.
- Implement account deletion in-app and a public deletion request URL where required.
- Set a minimum age and age-safety measures appropriate to the app's design and current Google Play policies.
- Do not expose exact GPS coordinates to other users.
- Do not store raw GPS coordinates when only the country is needed.
- Add rate limits and spam protection on the backend.
- Review Google Play user-generated content, Data safety, and billing policies before release.

## Project layout
- `lib/main.dart`: app entry point and navigation
- `lib/models.dart`: user and message models
- `lib/demo_data.dart`: local demo users/messages
- `lib/screens/`: onboarding, discovery, chat, profile and safety UI
- `lib/services/location_service.dart`: permission and country lookup
- `lib/services/chat_repository.dart`: demo repository boundary to replace with live backend
- `lib/theme.dart`: visual theme

## No payments in MVP
The prototype contains no ad SDK, billing SDK, subscription logic, or paid features.
