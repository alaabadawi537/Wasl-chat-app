import 'package:flutter/material.dart';

const waslNavy = Color(0xFF172D43);
const waslTeal = Color(0xFF2B7777);
const waslMint = Color(0xFFD9E8E7);
const waslCanvas = Color(0xFFF6F8FA);

ThemeData buildWaslTheme() {
  final scheme = ColorScheme.fromSeed(
    seedColor: waslTeal,
    brightness: Brightness.light,
    primary: waslTeal,
    secondary: waslNavy,
    surface: Colors.white,
  );
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: waslCanvas,
    appBarTheme: const AppBarTheme(
      backgroundColor: waslNavy,
      foregroundColor: Colors.white,
      centerTitle: false,
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Colors.white,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide.none,
      ),
    ),
    cardTheme: CardThemeData(
      color: Colors.white,
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
    ),
  );
}
