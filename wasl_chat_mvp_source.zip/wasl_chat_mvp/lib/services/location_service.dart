import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';

class CountryResult {
  final String code;
  final String name;
  const CountryResult({required this.code, required this.name});
}

class LocationService {
  /// Requests location only while onboarding, then returns the country.
  /// Do not persist raw coordinates when only the country is required.
  Future<CountryResult> detectCountry() async {
    final enabled = await Geolocator.isLocationServiceEnabled();
    if (!enabled) {
      throw Exception('فعّل خدمة الموقع لتحديد الدولة.');
    }

    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.denied) {
      throw Exception('نحتاج إذن الموقع لتحديد الدولة.');
    }
    if (permission == LocationPermission.deniedForever) {
      throw Exception('إذن الموقع مرفوض نهائيًا. فعّله من إعدادات الجهاز.');
    }

    final position = await Geolocator.getCurrentPosition(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.low,
        timeLimit: Duration(seconds: 15),
      ),
    );
    final places = await placemarkFromCoordinates(
      position.latitude,
      position.longitude,
    );
    if (places.isEmpty) {
      throw Exception('تعذر تحديد الدولة من الموقع.');
    }
    final place = places.first;
    final code = (place.isoCountryCode ?? '').toUpperCase();
    final name = place.country ?? '';
    if (code.isEmpty || name.isEmpty) {
      throw Exception('تعذر قراءة الدولة من بيانات الموقع.');
    }
    return CountryResult(code: code, name: name);
  }
}
