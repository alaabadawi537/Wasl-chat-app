import '../demo_data.dart';
import '../models.dart';

/// Demo-only repository. Replace with a secured Firebase implementation
/// before connecting real users. Client-side filtering is not a security
/// boundary; the server must enforce country and conversation access.
class ChatRepository {
  List<WaslUser> usersForCountry(String countryCode) {
    return demoUsers
        .where((u) => u.countryCode == countryCode)
        .toList(growable: false);
  }

  Future<void> sendText({
    required String senderId,
    required String recipientId,
    required String text,
  }) async {
    // Demo placeholder: no network request is made.
  }

  Future<void> sendAudio({
    required String senderId,
    required String recipientId,
    required String localPath,
  }) async {
    // Demo placeholder: upload to private cloud storage and save metadata.
  }
}
