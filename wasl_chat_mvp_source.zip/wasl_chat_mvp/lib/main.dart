import 'package:flutter/material.dart';
import 'screens/onboarding_screen.dart';
import 'theme.dart';

void main() {
  runApp(const WaslApp());
}

class WaslApp extends StatelessWidget {
  const WaslApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'WASL',
      debugShowCheckedModeBanner: false,
      theme: buildWaslTheme(),
      home: const OnboardingScreen(),
    );
  }
}
