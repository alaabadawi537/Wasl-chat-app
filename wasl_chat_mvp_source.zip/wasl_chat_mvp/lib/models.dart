class WaslUser {
  final String id;
  final String nickname;
  final String countryCode;
  final String countryName;
  final String status;
  final String bio;
  final String avatarLetter;

  const WaslUser({
    required this.id,
    required this.nickname,
    required this.countryCode,
    required this.countryName,
    required this.status,
    this.bio = '',
    required this.avatarLetter,
  });
}

enum MessageKind { text, audio }

class WaslMessage {
  final String id;
  final String senderId;
  final String recipientId;
  final MessageKind kind;
  final String text;
  final String? audioPath;
  final DateTime createdAt;

  const WaslMessage({
    required this.id,
    required this.senderId,
    required this.recipientId,
    required this.kind,
    required this.text,
    this.audioPath,
    required this.createdAt,
  });
}
