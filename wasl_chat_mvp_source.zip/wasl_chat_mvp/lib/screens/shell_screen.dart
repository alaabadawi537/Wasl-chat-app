import 'package:flutter/material.dart';
import '../demo_data.dart';
import '../models.dart';
import 'chat_screen.dart';
import 'discover_screen.dart';
import 'profile_screen.dart';

class ShellScreen extends StatefulWidget {
  final String countryCode;
  final String countryName;

  const ShellScreen({
    super.key,
    required this.countryCode,
    required this.countryName,
  });

  @override
  State<ShellScreen> createState() => _ShellScreenState();
}

class _ShellScreenState extends State<ShellScreen> {
  int index = 0;
  final Set<String> blocked = <String>{};

  void _openChat(WaslUser user) {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => ChatScreen(user: user),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      DiscoverScreen(
        countryCode: widget.countryCode,
        countryName: widget.countryName,
        blockedIds: blocked,
        onOpenChat: _openChat,
      ),
      const Center(child: Text('قائمة المحادثات ستظهر هنا بعد ربط الخادم.')),
      ProfileScreen(countryName: widget.countryName, countryCode: widget.countryCode),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('WASL'),
        actions: [
          Padding(
            padding: const EdgeInsetsDirectional.only(end: 16),
            child: Center(
              child: Text(widget.countryName,
                  style: const TextStyle(fontSize: 13, color: Colors.white70)),
            ),
          ),
        ],
      ),
      body: pages[index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (value) => setState(() => index = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.people_alt_outlined), label: 'اكتشف'),
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), label: 'المحادثات'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'حسابي'),
        ],
      ),
    );
  }
}
