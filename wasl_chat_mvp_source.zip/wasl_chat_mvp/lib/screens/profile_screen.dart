import 'package:flutter/material.dart';

class ProfileScreen extends StatelessWidget {
  final String countryName;
  final String countryCode;

  const ProfileScreen({
    super.key,
    required this.countryName,
    required this.countryCode,
  });

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const SizedBox(height: 12),
        const CircleAvatar(radius: 42, child: Icon(Icons.person, size: 42)),
        const SizedBox(height: 12),
        Text('حساب تجريبي', textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 6),
        Text('الدولة: $countryName ($countryCode)',
            textAlign: TextAlign.center),
        const SizedBox(height: 24),
        const Card(
          child: ListTile(
            leading: Icon(Icons.privacy_tip_outlined),
            title: Text('الخصوصية'),
            subtitle: Text('لا نعرض إحداثيات الموقع الدقيق للمستخدمين.'),
          ),
        ),
        const Card(
          child: ListTile(
            leading: Icon(Icons.block_outlined),
            title: Text('الحظر والإبلاغ'),
            subtitle: Text('ستُربط هذه الوظائف بنظام الإشراف في النسخة المتصلة بالخادم.'),
          ),
        ),
        const Card(
          child: ListTile(
            leading: Icon(Icons.delete_outline),
            title: Text('حذف الحساب'),
            subtitle: Text('يلزم تفعيل الحذف الفعلي من الخادم قبل الإطلاق العام.'),
          ),
        ),
        const SizedBox(height: 12),
        const Text(
          'الاشتراكات والإعلانات غير مفعّلة في النسخة الأولى.',
          textAlign: TextAlign.center,
          style: TextStyle(color: Colors.black54),
        ),
      ],
    );
  }
}
