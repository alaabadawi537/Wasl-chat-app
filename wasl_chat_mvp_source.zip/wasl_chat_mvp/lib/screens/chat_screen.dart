import 'dart:async';
import 'package:flutter/material.dart';
import 'package:record/record.dart';
import '../models.dart';

class ChatScreen extends StatefulWidget {
  final WaslUser user;
  const ChatScreen({super.key, required this.user});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final controller = TextEditingController();
  final recorder = AudioRecorder();
  final List<_LocalMessage> messages = <_LocalMessage>[
    _LocalMessage(text: 'أهلًا! 👋', mine: false),
  ];
  bool recording = false;
  String? recordingPath;

  @override
  void dispose() {
    controller.dispose();
    recorder.dispose();
    super.dispose();
  }

  void _sendText() {
    final text = controller.text.trim();
    if (text.isEmpty) return;
    setState(() {
      messages.add(_LocalMessage(text: text, mine: true));
      controller.clear();
    });
  }

  Future<void> _toggleRecording() async {
    try {
      if (!recording) {
        final allowed = await recorder.hasPermission();
        if (!allowed) {
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('يلزم السماح باستخدام الميكروفون.')),
            );
          }
          return;
        }
        final path = '${DateTime.now().millisecondsSinceEpoch}.m4a';
        await recorder.start(const RecordConfig(encoder: AudioEncoder.aacLc), path: path);
        setState(() => recording = true);
      } else {
        recordingPath = await recorder.stop();
        setState(() {
          recording = false;
          messages.add(_LocalMessage(
            text: 'تسجيل صوتي تجريبي جاهز محليًا',
            mine: true,
            audio: true,
          ));
        });
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('تم إنهاء التسجيل محليًا. الإرسال للطرف الآخر يحتاج خادمًا.'),
            ),
          );
        }
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تعذر بدء التسجيل. تحقق من صلاحية الميكروفون.')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            CircleAvatar(child: Text(widget.user.avatarLetter)),
            const SizedBox(width: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(widget.user.nickname, style: const TextStyle(fontSize: 16)),
                Text(widget.user.countryName,
                    style: const TextStyle(fontSize: 11, color: Colors.white70)),
              ],
            ),
          ],
        ),
        actions: [
          PopupMenuButton<String>(
            onSelected: (value) {
              final text = value == 'block'
                  ? 'تمت محاكاة الحظر في هذه الشاشة. يلزم تنفيذ الحظر على الخادم.'
                  : 'تمت محاكاة الإبلاغ. يلزم ربط البلاغ بنظام الإشراف.';
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'block', child: Text('حظر المستخدم')),
              PopupMenuItem(value: 'report', child: Text('الإبلاغ عن المستخدم')),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            color: const Color(0xFFEAF2F2),
            padding: const EdgeInsets.all(10),
            child: const Text(
              'نموذج محلي: رسائلك لا تُرسل إلى مستخدم حقيقي.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 12),
            ),
          ),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(14),
              itemCount: messages.length,
              itemBuilder: (context, index) {
                final message = messages[index];
                return Align(
                  alignment: message.mine ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    margin: const EdgeInsets.symmetric(vertical: 5),
                    padding: const EdgeInsets.all(12),
                    constraints: const BoxConstraints(maxWidth: 290),
                    decoration: BoxDecoration(
                      color: message.mine ? const Color(0xFFD9E8E7) : Colors.white,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        if (message.audio) const Icon(Icons.mic, size: 20),
                        if (message.audio) const SizedBox(width: 6),
                        Flexible(child: Text(message.text)),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(10, 8, 10, 10),
              child: Row(
                children: [
                  IconButton.filledTonal(
                    onPressed: _toggleRecording,
                    icon: Icon(recording ? Icons.stop : Icons.mic),
                    tooltip: recording ? 'إيقاف التسجيل' : 'تسجيل صوتي',
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: TextField(
                      controller: controller,
                      minLines: 1,
                      maxLines: 4,
                      decoration: const InputDecoration(hintText: 'اكتب رسالة...'),
                      onSubmitted: (_) => _sendText(),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton.filled(
                    onPressed: _sendText,
                    icon: const Icon(Icons.send),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _LocalMessage {
  final String text;
  final bool mine;
  final bool audio;
  const _LocalMessage({required this.text, required this.mine, this.audio = false});
}
