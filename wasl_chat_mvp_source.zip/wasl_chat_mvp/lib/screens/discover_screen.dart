import 'package:flutter/material.dart';
import '../demo_data.dart';
import '../models.dart';

class DiscoverScreen extends StatelessWidget {
  final String countryCode;
  final String countryName;
  final Set<String> blockedIds;
  final ValueChanged<WaslUser> onOpenChat;

  const DiscoverScreen({
    super.key,
    required this.countryCode,
    required this.countryName,
    required this.blockedIds,
    required this.onOpenChat,
  });

  @override
  Widget build(BuildContext context) {
    // Demo-only filter. Production must enforce this in backend security rules.
    final users = demoUsers.where((u) =>
        u.countryCode == countryCode && !blockedIds.contains(u.id)).toList();

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('أشخاص من بلدك', style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: 5),
        Text('الدولة: $countryName · لا يوجد تغيير يدوي للدولة',
            style: Theme.of(context).textTheme.bodySmall),
        const SizedBox(height: 16),
        if (users.isEmpty)
          const Card(
            child: Padding(
              padding: EdgeInsets.all(24),
              child: Text('لا توجد حسابات تجريبية لهذه الدولة حاليًا.'),
            ),
          ),
        ...users.map((user) => Card(
          child: ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            leading: CircleAvatar(
              radius: 25,
              child: Text(user.avatarLetter, style: const TextStyle(fontSize: 20)),
            ),
            title: Text(user.nickname),
            subtitle: Text('${user.countryName} · ${user.status}'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => onOpenChat(user),
          ),
        )),
        const SizedBox(height: 8),
        const Text(
          'الحسابات المعروضة تجريبية. لا يوجد مستخدمون حقيقيون في هذه النسخة.',
          style: TextStyle(fontSize: 12, color: Colors.black54),
        ),
      ],
    );
  }
}
