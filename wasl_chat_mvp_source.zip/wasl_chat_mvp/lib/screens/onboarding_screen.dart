import 'package:flutter/material.dart';
import '../services/location_service.dart';
import 'shell_screen.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  bool loading = false;
  String? error;

  Future<void> _continue() async {
    setState(() {
      loading = true;
      error = null;
    });
    try {
      final result = await LocationService().detectCountry();
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (_) => ShellScreen(
            countryCode: result.code,
            countryName: result.name,
          ),
        ),
      );
    } catch (e) {
      setState(() => error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(26),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Spacer(),
              Container(
                width: 76,
                height: 76,
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.primary,
                  borderRadius: BorderRadius.circular(24),
                ),
                child: const Icon(Icons.forum_rounded,
                    color: Colors.white, size: 38),
              ),
              const SizedBox(height: 24),
              Text('WASL', style: Theme.of(context).textTheme.headlineLarge?.copyWith(
                fontWeight: FontWeight.w800,
                letterSpacing: 2,
              )),
              const SizedBox(height: 8),
              Text(
                'دردشتك أقرب',
                style: Theme.of(context).textTheme.headlineSmall,
              ),
              const SizedBox(height: 14),
              const Text(
                'تواصل مع أشخاص من بلدك عبر الرسائل النصية والتسجيلات الصوتية.',
                style: TextStyle(fontSize: 16, height: 1.6),
              ),
              const SizedBox(height: 22),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Icon(Icons.location_on_outlined),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: const [
                            Text('لماذا نطلب الموقع؟',
                                style: TextStyle(fontWeight: FontWeight.w700)),
                            SizedBox(height: 5),
                            Text(
                              'لتحديد الدولة فقط. لن نعرض إحداثياتك أو موقعك الدقيق للمستخدمين الآخرين.',
                              style: TextStyle(height: 1.45),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              if (error != null) ...[
                const SizedBox(height: 12),
                Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
              ],
              const SizedBox(height: 14),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: loading ? null : _continue,
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Text(loading ? 'جارٍ تحديد الدولة...' : 'تحديد الدولة والمتابعة'),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              const Text(
                'نسخة أولية: يلزم ربط الحسابات والرسائل بخادم قبل الاستخدام العام.',
                style: TextStyle(fontSize: 12, color: Colors.black54),
              ),
              const Spacer(),
            ],
          ),
        ),
      ),
    );
  }
}
