import 'models.dart';

const demoCurrentUser = WaslUser(
  id: 'me',
  nickname: 'أنت',
  countryCode: 'SA',
  countryName: 'السعودية',
  status: 'متصل',
  bio: 'حساب تجريبي',
  avatarLetter: 'أ',
);

const demoUsers = <WaslUser>[
  WaslUser(
    id: 'nour',
    nickname: 'نور',
    countryCode: 'SA',
    countryName: 'السعودية',
    status: 'متصلة الآن',
    bio: 'أحب الكتب والقهوة وتبادل الثقافات.',
    avatarLetter: 'ن',
  ),
  WaslUser(
    id: 'omar',
    nickname: 'عمر',
    countryCode: 'SA',
    countryName: 'السعودية',
    status: 'نشط مؤخرًا',
    bio: 'مهتم بالتقنية والسفر.',
    avatarLetter: 'ع',
  ),
  WaslUser(
    id: 'lina',
    nickname: 'لينا',
    countryCode: 'SA',
    countryName: 'السعودية',
    status: 'متصلة الآن',
    bio: 'أحب تعلم اللغات.',
    avatarLetter: 'ل',
  ),
  WaslUser(
    id: 'sam',
    nickname: 'Sam',
    countryCode: 'US',
    countryName: 'United States',
    status: 'Online',
    bio: 'Demo account from another country.',
    avatarLetter: 'S',
  ),
];
